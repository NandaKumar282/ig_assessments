package week1_solutions;

public class LowBalanceException extends Exception {
    public LowBalanceException(String message) {
        super(message);
    }
}
