package week1_solutions;

public class Account {
    enum AccountType {
        SAVINGS, CURRENT
    }

    private Integer accNumber;
    private String custName;
    private AccountType type;
    private Float balance;

    public Account(Integer accNumber, String custName, String type, Float balance) throws LowBalanceException, InvalidAmountException {
        this.accNumber = accNumber;
        this.custName = custName;
        this.type = AccountType.valueOf(type.toUpperCase());
        if (balance < 0) {
            throw new InvalidAmountException("Balance cannot be negative");
        }
        this.balance = balance;

        if (this.type == AccountType.SAVINGS && balance < 1000) {
            throw new LowBalanceException("Low balance in Savings account. Minimum balance required is Rs.1000");
        } else if (this.type == AccountType.CURRENT && balance < 5000) {
            throw new LowBalanceException("Low balance in Current account. Minimum balance required is Rs.5000");
        }
    }

    public Integer getAccNumber() {
        return accNumber;
    }

    public void setAccNumber(Integer accNumber) {
        this.accNumber = accNumber;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public AccountType getType() {
        return type;
    }

    public void setType(AccountType type) {
        this.type = type;
    }

    public Float getBalance() {
        return balance;
    }

    public void setBalance(Float balance) {
        this.balance = balance;
    }
}



